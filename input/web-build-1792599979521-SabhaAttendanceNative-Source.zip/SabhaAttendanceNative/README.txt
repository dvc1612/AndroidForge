Sabha Attendance Android source project

IMPORTANT: This is source code, not a compiled APK. It has not been compiled or tested in this environment.

Before building:
1. Open app/src/main/java/com/example/sabhaattendance/MainActivity.kt
2. Replace PASTE_YOUR_DEPLOYED_APPS_SCRIPT_EXEC_URL_HERE with your deployed Apps Script Web App URL ending in /exec.
3. The Apps Script doGet(e) must support api=recordAttendance and call recordAttendanceFast(id). The endpoint patch is in AppsScript_API_PATCH.txt.
4. Confirm the QR code payload contains the member ID as ?id=MEMBER_ID or is itself the member ID.

The project uses CameraX and ML Kit for continuous QR scanning. Attendance calls the existing Apps Script endpoint. Dashboard button opens the Apps Script web app.
