package com.example.sabhaattendance

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {
    // Replace this placeholder with your deployed Google Apps Script Web App URL ending in /exec.
    private val scriptUrl = "PASTE_YOUR_DEPLOYED_APPS_SCRIPT_EXEC_URL_HERE"
    private lateinit var previewView: PreviewView
    private lateinit var status: TextView
    private val cameraExecutor = Executors.newSingleThreadExecutor()
    private var lastValue = ""
    private var lastScanAt = 0L
    private var webView: WebView? = null
    private val permission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startCamera() else status.text = "Camera permission is required to scan QR codes."
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20, 20, 20, 12) }
        val heading = TextView(this).apply { text = "Sabha Attendance"; textSize = 24f }
        status = TextView(this).apply { text = "Allow camera access to begin continuous QR scanning."; textSize = 16f; setPadding(0, 12, 0, 12) }
        previewView = PreviewView(this).apply { layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f) }
        val dashboard = Button(this).apply { text = "Open attendance dashboard"; setOnClickListener { openDashboard() } }
        root.addView(heading); root.addView(status); root.addView(previewView); root.addView(dashboard)
        setContentView(root)
        if (scriptUrl.startsWith("PASTE_")) status.text = "Setup needed: add your deployed Apps Script /exec URL in MainActivity.kt before building."
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startCamera()
        else permission.launch(Manifest.permission.CAMERA)
    }

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            val provider = providerFuture.get()
            val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
            val analysis = ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
            val scanner = BarcodeScanning.getClient()
            analysis.setAnalyzer(cameraExecutor) { proxy ->
                val mediaImage = proxy.image
                if (mediaImage == null) { proxy.close(); return@setAnalyzer }
                val image = InputImage.fromMediaImage(mediaImage, proxy.imageInfo.rotationDegrees)
                scanner.process(image).addOnSuccessListener { codes ->
                    val raw = codes.firstOrNull { !it.rawValue.isNullOrBlank() }?.rawValue ?: return@addOnSuccessListener
                    val now = System.currentTimeMillis()
                    if (raw == lastValue && now - lastScanAt < 3000) return@addOnSuccessListener
                    lastValue = raw; lastScanAt = now
                    val memberId = parseMemberId(raw)
                    runOnUiThread { status.text = "QR detected. Marking attendance…" }
                    markAttendance(memberId)
                }.addOnFailureListener { }.addOnCompleteListener { proxy.close() }
            }
            try {
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
            } catch (e: Exception) { status.text = "Could not start camera: ${e.message}" }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun parseMemberId(raw: String): String {
        return try {
            val uri = Uri.parse(raw)
            uri.getQueryParameter("id") ?: uri.getQueryParameter("memberId") ?: raw.trim()
        } catch (_: Exception) { raw.trim() }
    }

    private fun markAttendance(id: String) {
        if (scriptUrl.startsWith("PASTE_")) { runOnUiThread { status.text = "Setup needed: Apps Script URL has not been configured." }; return }
        Thread {
            var message = ""
            try {
                val url = URL("$scriptUrl?api=recordAttendance&id=${Uri.encode(id)}")
                val connection = (url.openConnection() as HttpURLConnection).apply { requestMethod = "GET"; connectTimeout = 15000; readTimeout = 15000 }
                val body = (if (connection.responseCode in 200..299) connection.inputStream else connection.errorStream).bufferedReader().use { it.readText() }
                message = "Server response: $body"
                connection.disconnect()
            } catch (e: Exception) { message = "Attendance request failed: ${e.message}" }
            runOnUiThread { status.text = message }
        }.start()
    }

    private fun openDashboard() {
        val web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.webViewClient = WebViewClient()
        web.loadUrl(if (scriptUrl.startsWith("PASTE_")) "https://script.google.com/home" else scriptUrl)
        webView = web
        setContentView(web)
    }

    override fun onDestroy() { super.onDestroy(); cameraExecutor.shutdown(); webView?.destroy() }
}
