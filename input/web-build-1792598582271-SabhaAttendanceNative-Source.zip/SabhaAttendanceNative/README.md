# Sabha Attendance Native Android source

This is an Android Studio source project using CameraX + ML Kit for continuous QR scanning. It calls your existing Google Apps Script web app and keeps Google Sheets as the attendance database. The Dashboard / Reports button opens your existing Apps Script web dashboard in a WebView.

## Configure
1. Open `app/src/main/java/com/sabha/attendance/MainActivity.kt`.
2. Replace `PASTE_YOUR_DEPLOYED_APPS_SCRIPT_EXEC_URL_HERE` with your deployed Apps Script URL ending in `/exec`.
3. Apply `../AppsScript_API_PATCH.txt` to your existing Code.gs. Add the API route at the top of `doGet`, before existing routes. Do not overwrite the existing script.
4. Deploy the Apps Script as a new version. Test the existing website first; your spreadsheet data is not migrated or reset.
5. Open this folder in Android Studio with JDK 17 and Android SDK 35. Sync Gradle, then Build > Build APK(s).

## Scan behavior
Camera stays open and analyzes frames continuously. Each QR payload can be either a member ID or a URL containing `?id=MEMBER_ID`. Server-side `recordAttendanceFast` remains responsible for validation and duplicate prevention.

## Important
This project source has not been built in this environment because Android SDK/Gradle are not installed here. Build and test on Android Studio before distributing. The web dashboard depends on your existing Apps Script deployment and permissions. The API endpoint must be protected appropriately for your actual deployment.
