package com.sabha.attendance

import android.Manifest
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import android.webkit.WebView
import android.webkit.WebViewClient
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.common.InputImage
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : AppCompatActivity() {
    // REQUIRED: paste your deployed Apps Script Web App URL ending in /exec.
    private val webAppUrl = "PASTE_YOUR_DEPLOYED_APPS_SCRIPT_EXEC_URL_HERE"
    private lateinit var root: LinearLayout
    private lateinit var status: TextView
    private lateinit var previewView: PreviewView
    private var webView: WebView? = null
    private val cameraExecutor = Executors.newSingleThreadExecutor()
    private val busy = AtomicBoolean(false)
    private var lastValue = ""
    private var lastAt = 0L
    private val permission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted -> if (granted) startCamera() else status.text = "Camera permission is required to scan QR codes." }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 18, 18, 18) }
        val title = TextView(this).apply { text = "Sabha Attendance"; textSize = 24f; setPadding(0, 0, 0, 12) }
        val actions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        actions.addView(Button(this).apply { text = "QR Scanner"; setOnClickListener { showScanner() } }, LinearLayout.LayoutParams(0, -2, 1f))
        actions.addView(Button(this).apply { text = "Dashboard / Reports"; setOnClickListener { showDashboard() } }, LinearLayout.LayoutParams(0, -2, 1f))
        status = TextView(this).apply { text = "Ready. Open QR Scanner to mark attendance."; textSize = 16f; setPadding(0, 12, 0, 12) }
        previewView = PreviewView(this)
        root.addView(title); root.addView(actions); root.addView(status)
        setContentView(root)
        showScanner()
    }

    private fun showScanner() {
        webView?.let { root.removeView(it); it.destroy(); webView = null }
        if (previewView.parent == null) root.addView(previewView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        status.text = "Camera ready: hold member QR codes in front of the camera. Scanning continues automatically."
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) startCamera() else permission.launch(Manifest.permission.CAMERA)
    }

    private fun showDashboard() {
        try { ProcessCameraProvider.getInstance(this).get().unbindAll() } catch (_: Exception) {}
        if (previewView.parent != null) root.removeView(previewView)
        if (webAppUrl.startsWith("PASTE_")) { status.text = "Set webAppUrl in MainActivity.kt to your deployed Apps Script /exec URL first."; return }
        webView?.let { root.removeView(it); it.destroy() }
        val w = WebView(this).apply { settings.javaScriptEnabled = true; settings.domStorageEnabled = true; webViewClient = WebViewClient(); loadUrl(webAppUrl) }
        webView = w
        root.addView(w, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        status.text = "Existing web dashboard and reports"
    }

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            try {
                val provider = providerFuture.get()
                val preview = Preview.Builder().build().also { it.setSurfaceProvider(previewView.surfaceProvider) }
                val scanner = BarcodeScanning.getClient()
                val analysis = ImageAnalysis.Builder().setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST).build()
                analysis.setAnalyzer(cameraExecutor) { imageProxy ->
                    val media = imageProxy.image
                    if (media == null) { imageProxy.close(); return@setAnalyzer }
                    scanner.process(InputImage.fromMediaImage(media, imageProxy.imageInfo.rotationDegrees))
                        .addOnSuccessListener { codes ->
                            val raw = codes.firstOrNull { it.rawValue?.isNotBlank() == true }?.rawValue ?: return@addOnSuccessListener
                            val now = System.currentTimeMillis()
                            if (raw == lastValue && now - lastAt < 2500) return@addOnSuccessListener
                            if (!busy.compareAndSet(false, true)) return@addOnSuccessListener
                            lastValue = raw; lastAt = now
                            val id = parseMemberId(raw)
                            if (id.isBlank()) { runOnUiThread { status.text = "QR not recognized as a member QR. Keep scanning…" }; busy.set(false) }
                            else sendAttendance(id)
                        }
                        .addOnCompleteListener { imageProxy.close() }
                }
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, preview, analysis)
            } catch (e: Exception) { status.text = "Camera error: ${e.message}" }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun parseMemberId(raw: String): String = try {
        val uri = Uri.parse(raw)
        (uri.getQueryParameter("id") ?: raw).trim()
    } catch (_: Exception) { raw.trim() }

    private fun sendAttendance(id: String) {
        Thread {
            var message = "Attendance request failed. Check internet and Apps Script deployment."
            try {
                val base = webAppUrl.trimEnd('/')
                val url = URL("$base?api=recordAttendance&id=" + URLEncoder.encode(id, "UTF-8"))
                val conn = (url.openConnection() as HttpURLConnection).apply { requestMethod = "GET"; connectTimeout = 15000; readTimeout = 20000; instanceFollowRedirects = true }
                val body = (if (conn.responseCode in 200..299) conn.inputStream else conn.errorStream).bufferedReader().use { it.readText() }
                val ok = body.contains("\"success\":true")
                val duplicate = body.contains("\"duplicate\":true")
                val name = Regex("\\\"name\\\"\\s*:\\s*\\\"([^\\\"]*)\\\"").find(body)?.groupValues?.get(1).orEmpty()
                val apiMessage = Regex("\\\"message\\\"\\s*:\\s*\\\"([^\\\"]*)\\\"").find(body)?.groupValues?.get(1).orEmpty()
                message = when { ok && duplicate -> "Already marked: $name"; ok -> "Attendance marked: $name"; else -> apiMessage.ifBlank { "Could not mark attendance: $body" } }
                conn.disconnect()
            } catch (e: Exception) { message = "Connection error: ${e.message}" }
            runOnUiThread { status.text = message; Toast.makeText(this, message, Toast.LENGTH_SHORT).show(); busy.set(false) }
        }.start()
    }

    override fun onDestroy() { super.onDestroy(); cameraExecutor.shutdown(); webView?.destroy() }
}
